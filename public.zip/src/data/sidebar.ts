// This is sample data.
export const data = {
  navMain: [
    {
      title: "الصفحة الرئيسة",
      url: "/home",
      items: [],
    },
    {
      title: "الشركات",
      url: "#",
    },
  ],
};
